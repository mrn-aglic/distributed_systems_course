﻿namespace AkkaReadWriteConsole.Messages
{
    class ConsoleInput
    {
    }
}
